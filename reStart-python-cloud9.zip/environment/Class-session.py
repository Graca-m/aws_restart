names={"wei","nikki","akua"}
for  name in names:
     Newname=name.capitalize () 
     print(Newname)

