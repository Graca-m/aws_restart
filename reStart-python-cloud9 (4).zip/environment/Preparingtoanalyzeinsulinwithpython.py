import re
with open('preproinsulin-seq.txt','r') as f:
    with open('preproinsulin-seq-clean.txt','w') as cleaned:
        while True:
            lines = f.readline()
            cleanline = re.sub("[ORIGIN|//|(0-9)|\n\r|\s+]","",lines)
            cleaned.write(cleanline)
            if not lines:
               break
with open('preproinsulin-seq-clean.txt', 'r') as cleaned_file:
    line = cleaned_file.readline()
    with open('lsinsulin-seq-clean.txt', 'w') as seq:
        seq.write(line[0:24])
    with open('binsulin-seq-clean.txt', 'w') as seq:
        seq.write(line[24:54])
    with open('cinsulin-seq-clean.txt' , 'w') as seq:
        seq.write(line[54:89])
    with open('ainsulin-seq-clean.txt' , 'w') as seq:
        seq.write(line[89:110])

        
        
        
